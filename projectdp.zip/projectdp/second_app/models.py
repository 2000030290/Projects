from django.db import models

# Create your models here.
from django.db import models
# class tb1_auth(models.Mode1):
#     fname=models.CharField(max_length=50,default='')
#     lname = models.CharField(max_length=50, default='')
#     email=models.EmailField(default='')
#     password=models.CharField(max_length=50,default='')
#
#     def __str__(self):
#         return self.email
#
#     tth_ob=models.Manager()
